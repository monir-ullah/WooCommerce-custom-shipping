<?php
/*
Plugin Name: WooCommerce City Zones
Plugin URI: https://example.com/
Description: Add a custom City Zones repeater field under WooCommerce → Shipping Zones.
Version: 1.1
Author: Monir Ullah
*/

if (!defined('ABSPATH'))
    exit;

// -----------------------------
// Add the repeater UI to Shipping Zones page
// -----------------------------
add_action('woocommerce_settings_shipping', function () {
    // Check if enabled
    $enabled = get_option('wc_city_zones_enabled', 'yes');
    if ($enabled !== 'yes')
        return;

    $screen = get_current_screen();
    if (!isset($screen->id) || $screen->id !== 'woocommerce_page_wc-settings')
        return;
    if (!isset($_GET['tab']) || $_GET['tab'] !== 'shipping' || !empty($_GET['section']))
        return;

    // Get existing saved data
    $data = get_option('wc_city_zones_main_repeater', '[]');
    $items = json_decode($data, true);
    if (!is_array($items))
        $items = [];

    ?>
    <div id="cz-main-repeater"
        style="margin-top:30px;padding:20px;background:#fff;border:1px solid #ddd;border-radius:6px;">
        <h2 style="margin-top:0;">City Zones Shipping Rates</h2>
        <p class="description">Add city-based delivery rates (e.g., Inside Dhaka, Outside Dhaka). These are saved
            automatically via AJAX.</p>

        <table class="widefat striped">
            <thead>
                <tr>
                    <th style="width:40%">Label</th>
                    <th style="width:40%">Price (৳)</th>
                    <th style="width:20%">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($items)): ?>
                    <?php foreach ($items as $row): ?>
                        <tr>
                            <td><input type="text" class="cz-label" value="<?php echo esc_attr($row['label']); ?>"
                                    style="width:100%"></td>
                            <td><input type="number" step="0.01" min="0" class="cz-price"
                                    value="<?php echo esc_attr($row['price']); ?>" style="width:100%"></td>
                            <td><button type="button" class="button link-delete cz-remove">Remove</button></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <p>
            <button type="button" class="button button-primary cz-add">Add Option</button>
            <span class="cz-saving" style="display:none;margin-left:10px;color:#2271b1;">Saving...</span>
        </p>
    </div>

    <script>
        jQuery(function ($) {
            const $wrap = $('#cz-main-repeater');
            const $tbody = $wrap.find('tbody');

            function readRows() {
                let rows = [];
                $tbody.find('tr').each(function () {
                    rows.push({
                        label: $(this).find('.cz-label').val() || '',
                        price: parseFloat($(this).find('.cz-price').val() || '0') || 0
                    });
                });
                return rows;
            }

            function saveRows() {
                $wrap.find('.cz-saving').show();
                $.post(ajaxurl, {
                    action: 'wc_city_zones_main_save',
                    nonce: '<?php echo wp_create_nonce('wc_cz_main_nonce'); ?>',
                    data: JSON.stringify(readRows())
                }).always(() => $wrap.find('.cz-saving').fadeOut(300));
            }

            $wrap.on('click', '.cz-add', function () {
                $tbody.append(`<tr>
                <td><input type="text" class="cz-label" placeholder="e.g. Inside Dhaka" style="width:100%"></td>
                <td><input type="number" step="0.01" min="0" class="cz-price" placeholder="0.00" style="width:100%"></td>
                <td><button type="button" class="button link-delete cz-remove">Remove</button></td>
            </tr>`);
                saveRows();
            });

            $wrap.on('click', '.cz-remove', function () {
                $(this).closest('tr').remove();
                saveRows();
            });

            $wrap.on('input change', '.cz-label, .cz-price', function () {
                clearTimeout(window.czSaveTimer);
                window.czSaveTimer = setTimeout(saveRows, 600);
            });
        });
    </script>
    <?php
});

// -----------------------------
// Handle AJAX save for repeater
// -----------------------------
add_action('wp_ajax_wc_city_zones_main_save', function () {
    check_ajax_referer('wc_cz_main_nonce', 'nonce');

    $data = isset($_POST['data']) ? wp_unslash($_POST['data']) : '[]';
    $items = json_decode($data, true);
    if (!is_array($items))
        $items = [];

    $clean = array_map(function ($r) {
        return [
            'label' => sanitize_text_field($r['label'] ?? ''),
            'price' => floatval($r['price'] ?? 0)
        ];
    }, $items);

    update_option('wc_city_zones_main_repeater', wp_json_encode($clean));
    wp_send_json_success(['saved' => true]);
});

// -----------------------------
// Handle AJAX save for enable/disable
// -----------------------------
add_action('wp_ajax_wc_city_zones_toggle_enable', function () {
    check_ajax_referer('wc_cz_toggle_nonce', 'nonce');
    $enabled = sanitize_text_field($_POST['enabled'] ?? 'no');
    update_option('wc_city_zones_enabled', $enabled === 'yes' ? 'yes' : 'no');
    wp_send_json_success(['enabled' => $enabled]);
});

// -----------------------------
// Add submenu under WooCommerce
// -----------------------------
add_action('admin_menu', function () {
    add_submenu_page(
        'woocommerce',
        'City Zones',
        'City Zones',
        'manage_woocommerce',
        'wc-city-zones',
        function () {
            $enabled = get_option('wc_city_zones_enabled', 'yes');
            ?>
        <div class="wrap">
            <h1>City Zones Settings</h1>
            <p>Control your City Zones module here. When disabled, it will not appear under the Shipping tab.</p>

            <table class="form-table">
                <tr>
                    <th scope="row">Enable City Zones</th>
                    <td>
                        <label>
                            <input type="checkbox" id="cz-enable-toggle" <?php checked($enabled, 'yes'); ?>> Enable
                        </label>
                        <span class="cz-saving" style="display:none;margin-left:10px;color:#2271b1;">Saving...</span>
                    </td>
                </tr>
            </table>
        </div>

        <script>
            jQuery(function ($) {
                $('#cz-enable-toggle').on('change', function () {
                    $('.cz-saving').show();
                    $.post(ajaxurl, {
                        action: 'wc_city_zones_toggle_enable',
                        nonce: '<?php echo wp_create_nonce('wc_cz_toggle_nonce'); ?>',
                        enabled: this.checked ? 'yes' : 'no'
                    }).always(() => $('.cz-saving').fadeOut(300));
                });
            });
        </script>
        <?php
        }
    );
});
