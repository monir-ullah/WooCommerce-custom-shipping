<?php
/*
Plugin Name: WooCommerce City Zones
Plugin URI: https://example.com/
Description: Add a custom City Zones repeater field under WooCommerce → Settings → Shipping.
Version: 1.2
Author: Monir Ullah
*/

if (!defined('ABSPATH'))
    exit;

// -----------------------------
// Add toggle + repeater under Shipping Tab
// -----------------------------
add_action('woocommerce_settings_shipping', function () {
    $screen = get_current_screen();
    if (!isset($screen->id) || $screen->id !== 'woocommerce_page_wc-settings')
        return;
    if (!isset($_GET['tab']) || $_GET['tab'] !== 'shipping' || !empty($_GET['section']))
        return;

    $enabled = get_option('wc_city_zones_enabled', 'yes');

    ?>
    <div id="cz-enable-box" style="margin-top:25px;padding:20px;background:#fff;border:1px solid #ddd;border-radius:6px;">
        <h2 style="margin-top:0;">City Zones Settings</h2>
        <p>Enable or disable City Zones. When disabled, the City Zones rate list below will be hidden.</p>

        <label class="cz-switch">
            <input type="checkbox" id="cz-enable-toggle" <?php checked($enabled, 'yes'); ?>>
            <span class="cz-slider round"></span>
        </label>
        <span class="cz-status" style="margin-left:10px;">
            <?php echo $enabled === 'yes' ? '✅ Enabled' : '❌ Disabled'; ?>
        </span>
        <span class="cz-saving" style="display:none;margin-left:10px;color:#2271b1;">Saving...</span>
    </div>

    <style>
        /* Toggle Switch */
        .cz-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 26px;
        }

        .cz-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .cz-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 26px;
        }

        .cz-slider:before {
            position: absolute;
            content: "";
            height: 20px;
            width: 20px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked+.cz-slider {
            background-color: #2271b1;
        }

        input:checked+.cz-slider:before {
            transform: translateX(24px);
        }
    </style>

    <script>
        jQuery(function ($) {
            const $wrap = $('#cz-main-repeater');
            const $toggle = $('#cz-enable-toggle');

            // Handle toggle change
            $toggle.on('change', function () {
                const enabled = this.checked ? 'yes' : 'no';
                $('.cz-saving').show();
                $.post(ajaxurl, {
                    action: 'wc_city_zones_toggle_enable',
                    nonce: '<?php echo wp_create_nonce('wc_cz_toggle_nonce'); ?>',
                    enabled
                }, function (res) {
                    $('.cz-saving').fadeOut(300);
                    $('.cz-status').text(enabled === 'yes' ? '✅ Enabled' : '❌ Disabled');
                    if (enabled === 'yes') {
                        $('#cz-main-repeater').slideDown(300);
                    } else {
                        $('#cz-main-repeater').slideUp(300);
                    }
                });
            });
        });
    </script>
    <?php

    // Stop here if disabled
    if ($enabled !== 'yes')
        return;

    // -----------------------------
    // Repeater UI
    // -----------------------------
    $data = get_option('wc_city_zones_main_repeater', '[]');
    $items = json_decode($data, true);
    if (!is_array($items))
        $items = [];
    ?>
    <div id="cz-main-repeater"
        style="margin-top:30px;padding:20px;background:#fff;border:1px solid #ddd;border-radius:6px;">
        <h2 style="margin-top:0;">City Zones Shipping Rates</h2>
        <p class="description">Add city-based delivery rates (e.g., Inside Dhaka, Outside Dhaka). These are saved
            automatically via AJAX.</p>

        <table class="widefat striped">
            <thead>
                <tr>
                    <th style="width:40%">Label</th>
                    <th style="width:40%">Price <?php echo get_woocommerce_currency_symbol(); ?></th>
                    <th style="width:20%">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $row): ?>
                    <tr>
                        <td><input type="text" class="cz-label" value="<?php echo esc_attr($row['label']); ?>"
                                style="width:100%"></td>
                        <td><input type="number" step="0.01" min="0" class="cz-price"
                                value="<?php echo esc_attr($row['price']); ?>" style="width:100%"></td>
                        <td><button type="button" class="button link-delete cz-remove">Remove</button></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p>
            <button type="button" class="button button-primary cz-add">Add Option</button>
            <span class="cz-saving" style="display:none;margin-left:10px;color:#2271b1;">Saving...</span>
        </p>
    </div>

    <script>
        jQuery(function ($) {
            const $wrap = $('#cz-main-repeater');
            const $tbody = $wrap.find('tbody');

            function readRows() {
                let rows = [];
                $tbody.find('tr').each(function () {
                    rows.push({
                        label: $(this).find('.cz-label').val() || '',
                        price: parseFloat($(this).find('.cz-price').val() || '0') || 0
                    });
                });
                return rows;
            }

            function saveRows() {
                $wrap.find('.cz-saving').show();
                $.post(ajaxurl, {
                    action: 'wc_city_zones_main_save',
                    nonce: '<?php echo wp_create_nonce('wc_cz_main_nonce'); ?>',
                    data: JSON.stringify(readRows())
                }).always(() => $wrap.find('.cz-saving').fadeOut(300));
            }

            $wrap.on('click', '.cz-add', function () {
                $tbody.append(`<tr>
                    <td><input type="text" class="cz-label" placeholder="e.g. Inside Dhaka" style="width:100%"></td>
                    <td><input type="number" step="0.01" min="0" class="cz-price" placeholder="0.00" style="width:100%"></td>
                    <td><button type="button" class="button link-delete cz-remove">Remove</button></td>
                </tr>`);
                saveRows();
            });

            $wrap.on('click', '.cz-remove', function () {
                $(this).closest('tr').remove();
                saveRows();
            });

            $wrap.on('input change', '.cz-label, .cz-price', function () {
                clearTimeout(window.czSaveTimer);
                window.czSaveTimer = setTimeout(saveRows, 600);
            });
        });
    </script>
    <?php
});

// -----------------------------
// Handle AJAX save
// -----------------------------
add_action('wp_ajax_wc_city_zones_main_save', function () {
    check_ajax_referer('wc_cz_main_nonce', 'nonce');

    $data = isset($_POST['data']) ? wp_unslash($_POST['data']) : '[]';
    $items = json_decode($data, true);
    if (!is_array($items))
        $items = [];

    $clean = array_map(function ($r) {
        return [
            'label' => sanitize_text_field($r['label'] ?? ''),
            'price' => floatval($r['price'] ?? 0)
        ];
    }, $items);

    update_option('wc_city_zones_main_repeater', wp_json_encode($clean));
    wp_send_json_success(['saved' => true]);
});

// -----------------------------
// Handle AJAX toggle
// -----------------------------
add_action('wp_ajax_wc_city_zones_toggle_enable', function () {
    check_ajax_referer('wc_cz_toggle_nonce', 'nonce');
    $enabled = sanitize_text_field($_POST['enabled'] ?? 'no');
    update_option('wc_city_zones_enabled', $enabled === 'yes' ? 'yes' : 'no');
    wp_send_json_success(['enabled' => $enabled]);
});



// Add city zones radio buttons on checkout
add_action('woocommerce_review_order_before_shipping', function () {
    $enabled = get_option('wc_city_zones_enabled');
    if ($enabled !== 'yes')
        return;

    $zones = get_option('wc_city_zones_main_repeater', []);
    if (empty($zones))
        return;

    echo '<div id="wc-city-zones" class="wc-city-zones">';
    echo '<h3>Select Your City Zone</h3>';

    foreach ($zones as $index => $zone) {
        $zone_name = esc_html($zone['city_name'] ?? '');
        $zone_cost = floatval($zone['shipping_cost'] ?? 0);
        echo '<p>';
        echo '<input type="radio" name="wc_city_zone" value="' . $index . '" data-cost="' . $zone_cost . '" id="wc-city-zone-' . $index . '">';
        echo '<label for="wc-city-zone-' . $index . '">' . $zone_name . ' - ' . wc_price($zone_cost) . '</label>';
        echo '</p>';
    }

    echo '</div>';
}, 20);

// Save the selected zone in session
add_action('woocommerce_checkout_update_order_review', function ($posted_data) {
    parse_str($posted_data, $output);
    if (!empty($output['wc_city_zone'])) {
        WC()->session->set('wc_city_zone', $output['wc_city_zone']);
    }
});

// Add shipping cost based on selected zone
add_action('woocommerce_cart_calculate_fees', function ($cart) {
    if (is_admin() && !defined('DOING_AJAX'))
        return;

    $selected_zone = WC()->session->get('wc_city_zone');
    if ($selected_zone === null)
        return;

    $zones = get_option('wc_city_zones_main_repeater', []);
    if (isset($zones[$selected_zone]['shipping_cost'])) {
        $cost = floatval($zones[$selected_zone]['shipping_cost']);
        $cart->add_fee('City Zone Shipping', $cost);
    }
});

// Ensure AJAX updates when selecting zone
add_action('wp_footer', function () {
    if (!is_checkout())
        return;
    ?>
    <script type="text/javascript">
        jQuery(function ($) {
            $('input[name="wc_city_zone"]').on('change', function () {
                $('body').trigger('update_checkout'); // refresh totals
            });
        });
    </script>
    <?php
});
